﻿init
{
	$SODX 264 256 265 82 67 65 66 69;
	$SHZ 50000;
}

fn main(scanFreq=50000)
{
	ellipse(x0=0.0000, y0=0.0000, radX=15.0000, radY=5.0000, angle=0.0000, nTurns=1.0000, numPts=7500,waitAtBegin=10000, label="ellipse1")
}

