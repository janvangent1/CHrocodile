﻿init
{
	$SODX 264 256 265 82 67 65 66 69;
	$SHZ 50000;
}

fn main(scanFreq=50000)
{
	spiral(x0=-14.8907, y0=16.4208, a=0.0000, b=0.4232, nTurns=3, numPts=1000,waitAtBegin=10000, label="spiral1")
}

